
import { useState, useEffect, useRef } from 'react';
import { Youtube, Instagram, Github, Linkedin, TrendingUp, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SocialCounterSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  // Animated counter hook
  const useCountUp = (end: number, duration: number = 2000, start: number = 0) => {
    const [count, setCount] = useState(start);
    const [shouldStart, setShouldStart] = useState(false);

    useEffect(() => {
      if (!shouldStart) return;

      let startTime: number;
      const animate = (currentTime: number) => {
        if (!startTime) startTime = currentTime;
        const progress = Math.min((currentTime - startTime) / duration, 1);
        
        const easeOutQuart = 1 - Math.pow(1 - progress, 4);
        setCount(Math.floor(start + (end - start) * easeOutQuart));

        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };

      requestAnimationFrame(animate);
    }, [shouldStart, end, duration, start]);

    return { count, startCounting: () => setShouldStart(true) };
  };

  // Intersection Observer for scroll animation
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !isVisible) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, [isVisible]);

  const socialStats = [
    {
      platform: 'YouTube',
      icon: Youtube,
      count: 112,
      newToday: 18,
      color: 'text-red-500',
      bgGradient: 'from-red-500/10 to-red-600/5',
      borderColor: 'border-red-200 dark:border-red-800',
      hoverBg: 'hover:bg-red-50 dark:hover:bg-red-950/20',
      url: '#',
      label: 'Subscribers'
    },
    {
      platform: 'Instagram',
      icon: Instagram,
      count: 15000,
      newToday: 7,
      color: 'text-pink-500',
      bgGradient: 'from-pink-500/10 to-purple-500/5',
      borderColor: 'border-pink-200 dark:border-pink-800',
      hoverBg: 'hover:bg-pink-50 dark:hover:bg-pink-950/20',
      url: 'https://www.instagram.com/najish.onic',
      label: 'Followers'
    },
    {
      platform: 'GitHub',
      icon: Github,
      count: 10,
      newToday: 12,
      color: 'text-gray-700 dark:text-gray-300',
      bgGradient: 'from-gray-500/10 to-gray-600/5',
      borderColor: 'border-gray-200 dark:border-gray-700',
      hoverBg: 'hover:bg-gray-50 dark:hover:bg-gray-800/50',
      url: 'https://github.com/Najishanjum',
      label: 'Followers'
    },
    {
      platform: 'LinkedIn',
      icon: Linkedin,
      count: 810,
      newToday: 12,
      color: 'text-blue-600',
      bgGradient: 'from-blue-500/10 to-blue-600/5',
      borderColor: 'border-blue-200 dark:border-blue-800',
      hoverBg: 'hover:bg-blue-50 dark:hover:bg-blue-950/20',
      url: 'https://www.linkedin.com/in/md-najish-anjum-044078328',
      label: 'Connections'
    }
  ];

  return (
    <section 
      ref={sectionRef}
      className="py-20 bg-gradient-to-br from-blue-50/50 via-white to-purple-50/30 dark:from-gray-900 dark:via-gray-800 dark:to-blue-900/10 font-inter"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/30 dark:to-purple-900/30 rounded-full text-blue-700 dark:text-blue-300 text-sm font-medium mb-4 backdrop-blur-sm border border-blue-200/50 dark:border-blue-700/50">
            <TrendingUp className="w-4 h-4 mr-2 animate-bounce" />
            Live Social Stats
          </div>
          
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4 font-poppins">
            Growing <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Community</span>
          </h2>
          
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Join thousands of followers across platforms as we explore technology, development, and innovation together
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {socialStats.map((stat, index) => {
            const { count, startCounting } = useCountUp(stat.count, 2000 + index * 200);
            
            useEffect(() => {
              if (isVisible) {
                const timer = setTimeout(() => startCounting(), index * 150);
                return () => clearTimeout(timer);
              }
            }, [isVisible, startCounting, index]);

            return (
              <div 
                key={stat.platform}
                className={`relative group bg-white/70 dark:bg-gray-800/50 backdrop-blur-sm rounded-2xl p-6 border ${stat.borderColor} ${stat.hoverBg} transition-all duration-500 hover:shadow-xl hover:scale-105 cursor-pointer animate-fadeInUp`}
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => window.open(stat.url, '_blank')}
              >
                {/* Gradient Background */}
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.bgGradient} rounded-2xl opacity-50 group-hover:opacity-70 transition-opacity duration-300`} />
                
                {/* Content */}
                <div className="relative z-10">
                  {/* Platform Icon & New Badge */}
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-xl bg-white dark:bg-gray-700 shadow-md group-hover:scale-110 transition-transform duration-300`}>
                      <stat.icon className={`w-6 h-6 ${stat.color}`} />
                    </div>
                    
                    <div className="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 px-2 py-1 rounded-full text-xs font-medium border border-green-200 dark:border-green-800">
                      +{stat.newToday} today
                    </div>
                  </div>

                  {/* Count */}
                  <div className="mb-2">
                    <div className="text-3xl font-bold text-gray-900 dark:text-white font-poppins group-hover:scale-105 transition-transform duration-300">
                      {isVisible ? count.toLocaleString() : '0'}
                    </div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      {stat.label}
                    </div>
                  </div>

                  {/* Platform Name */}
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                      {stat.platform}
                    </span>
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" title="Live" />
                  </div>
                </div>

                {/* Hover Glow Effect */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-400/0 via-purple-400/0 to-pink-400/0 group-hover:from-blue-400/10 group-hover:via-purple-400/10 group-hover:to-pink-400/10 transition-all duration-500" />
              </div>
            );
          })}
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl p-8 border border-gray-200 dark:border-gray-700 inline-block shadow-lg">
            <div className="flex items-center justify-center mb-4">
              <Users className="w-8 h-8 text-blue-500 mr-3 animate-bounce-gentle" />
              <span className="text-2xl font-bold text-gray-900 dark:text-white font-poppins">
                Join the Community
              </span>
            </div>
            
            <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-md">
              Follow me across platforms for the latest updates on tech, development tutorials, and exciting projects!
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                onClick={() => window.open('https://www.youtube.com/@najishanjum', '_blank')}
              >
                <Youtube className="w-5 h-5 mr-2" />
                Subscribe on YouTube
              </Button>
              
              <Button 
                variant="outline"
                size="lg"
                className="border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800 transition-all duration-300 backdrop-blur-sm"
                onClick={() => window.open('https://github.com/Najishanjum', '_blank')}
              >
                <Github className="w-5 h-5 mr-2" />
                Follow on GitHub
              </Button>
            </div>
          </div>
        </div>

        {/* Last Updated */}
        <div className="text-center mt-8">
          <div className="inline-flex items-center text-sm text-gray-500 dark:text-gray-400">
            <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
            Last updated: {new Date().toLocaleTimeString()}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SocialCounterSection;
