
import { useState, useEffect, useRef } from 'react';

const SkillsSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  const skills = [
    { name: 'HTML/CSS', level: 90, icon: '🌐', color: 'from-orange-400 to-red-500', glowColor: 'shadow-orange-500/50' },
    { name: 'Python', level: 80, icon: '🐍', color: 'from-green-400 to-blue-500', glowColor: 'shadow-green-500/50' },
    { name: 'AI/ML', level: 80, icon: '🤖', color: 'from-purple-400 to-pink-500', glowColor: 'shadow-purple-500/50' },
    { name: 'JavaScript', level: 50, icon: '⚡', color: 'from-yellow-400 to-orange-500', glowColor: 'shadow-yellow-500/50' },
    { name: 'Firebase', level: 50, icon: '🔥', color: 'from-red-400 to-pink-500', glowColor: 'shadow-red-500/50' },
    { name: 'React', level: 20, icon: '⚛️', color: 'from-cyan-400 to-blue-500', glowColor: 'shadow-cyan-500/50' }
  ];

  // Animated counter for percentages
  const useCountUp = (end: number, duration: number = 2000) => {
    const [count, setCount] = useState(0);
    const [shouldStart, setShouldStart] = useState(false);

    useEffect(() => {
      if (!shouldStart) return;

      let startTime: number;
      const animate = (currentTime: number) => {
        if (!startTime) startTime = currentTime;
        const progress = Math.min((currentTime - startTime) / duration, 1);
        
        const easeOutQuart = 1 - Math.pow(1 - progress, 4);
        setCount(Math.floor(end * easeOutQuart));

        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };

      requestAnimationFrame(animate);
    }, [shouldStart, end, duration]);

    return { count, startCounting: () => setShouldStart(true) };
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      id="skills" 
      ref={sectionRef} 
      className="py-20 bg-gradient-to-br from-slate-900 via-gray-900 to-black relative overflow-hidden"
    >
      {/* Animated Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Neural Network Pattern */}
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" viewBox="0 0 1000 1000">
            <defs>
              <pattern id="neural" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
                <circle cx="20" cy="20" r="2" fill="cyan" opacity="0.5">
                  <animate attributeName="opacity" values="0.5;1;0.5" dur="3s" repeatCount="indefinite" />
                </circle>
                <circle cx="80" cy="80" r="1.5" fill="purple" opacity="0.3">
                  <animate attributeName="opacity" values="0.3;0.8;0.3" dur="4s" repeatCount="indefinite" />
                </circle>
                <line x1="20" y1="20" x2="80" y2="80" stroke="cyan" strokeWidth="0.5" opacity="0.3">
                  <animate attributeName="stroke-opacity" values="0.1;0.5;0.1" dur="2s" repeatCount="indefinite" />
                </line>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#neural)" />
          </svg>
        </div>

        {/* Floating Particles */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-cyan-400 rounded-full opacity-30 animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${3 + Math.random() * 4}s`
              }}
            />
          ))}
        </div>

        {/* Matrix Rain Effect */}
        <div className="absolute inset-0 opacity-5">
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              className="absolute text-green-400 text-xs font-mono animate-bounce"
              style={{
                left: `${i * 2}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 3}s`
              }}
            >
              {Math.random() > 0.5 ? '1' : '0'}
            </div>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-full border border-cyan-500/30 backdrop-blur-sm mb-6">
            <span className="text-2xl mr-3 animate-pulse">🧠</span>
            <span className="text-cyan-400 font-mono text-sm font-medium tracking-wider">
              AI_SKILL_MATRIX.EXE
            </span>
          </div>
          
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 font-poppins">
            <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
              Neural Skills
            </span>
          </h2>
          
          <p className="text-lg text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Advanced technical proficiency powered by continuous learning algorithms
          </p>
        </div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {skills.map((skill, index) => {
            const { count, startCounting } = useCountUp(skill.level, 2000 + index * 300);
            
            useEffect(() => {
              if (isVisible) {
                const timer = setTimeout(() => startCounting(), index * 200);
                return () => clearTimeout(timer);
              }
            }, [isVisible, startCounting, index]);

            return (
              <div 
                key={skill.name}
                className="group relative bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-cyan-500/20 hover:border-cyan-400/40 transition-all duration-500 hover:shadow-2xl hover:shadow-cyan-500/20 animate-fadeInUp"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                {/* Holographic Glow Effect */}
                <div className={`absolute inset-0 rounded-2xl bg-gradient-to-r ${skill.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500 blur-xl`} />
                
                {/* Content */}
                <div className="relative z-10">
                  {/* Icon */}
                  <div className="flex items-center justify-center w-16 h-16 mb-6 mx-auto">
                    <span 
                      className="text-4xl filter drop-shadow-lg transform group-hover:scale-110 transition-transform duration-300"
                      style={{ 
                        filter: 'drop-shadow(0 0 10px currentColor)',
                        textShadow: '0 0 20px currentColor'
                      }}
                    >
                      {skill.icon}
                    </span>
                  </div>

                  {/* Skill Name */}
                  <h3 className="text-xl font-bold text-white mb-4 text-center font-poppins group-hover:text-cyan-300 transition-colors duration-300">
                    {skill.name}
                  </h3>

                  {/* Progress Circle */}
                  <div className="relative w-32 h-32 mx-auto mb-4">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                      {/* Background Circle */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        className="text-gray-700"
                      />
                      
                      {/* Progress Circle */}
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="url(#gradient-${index})"
                        strokeWidth="8"
                        fill="none"
                        strokeLinecap="round"
                        strokeDasharray={`${2 * Math.PI * 40}`}
                        strokeDashoffset={`${2 * Math.PI * 40 * (1 - (isVisible ? skill.level : 0) / 100)}`}
                        className="transition-all duration-2000 ease-out drop-shadow-lg"
                        style={{
                          filter: 'drop-shadow(0 0 8px currentColor)',
                          transitionDelay: `${index * 200}ms`
                        }}
                      />
                      
                      {/* SVG Gradients */}
                      <defs>
                        <linearGradient id={`gradient-${index}`} x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="cyan" />
                          <stop offset="50%" stopColor="blue" />
                          <stop offset="100%" stopColor="purple" />
                        </linearGradient>
                      </defs>
                    </svg>
                    
                    {/* Percentage Text */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl font-bold text-cyan-400 font-mono">
                        {isVisible ? count : 0}%
                      </span>
                    </div>
                  </div>

                  {/* Digital Status */}
                  <div className="text-center">
                    <div className="inline-flex items-center px-3 py-1 bg-cyan-500/20 rounded-full border border-cyan-500/30">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full mr-2 animate-pulse" />
                      <span className="text-xs text-cyan-300 font-mono tracking-wider">
                        ACTIVE
                      </span>
                    </div>
                  </div>
                </div>

                {/* Hover Glow Lines */}
                <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                  <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse" />
                  <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-purple-400 to-transparent animate-pulse" />
                </div>
              </div>
            );
          })}
        </div>

        {/* AI Status Panel */}
        <div className="text-center">
          <div className="inline-block bg-gradient-to-r from-gray-900/80 to-black/80 backdrop-blur-sm rounded-2xl p-8 border border-cyan-500/30 shadow-2xl shadow-cyan-500/10">
            <div className="flex items-center justify-center mb-4">
              <div className="w-3 h-3 bg-green-400 rounded-full mr-3 animate-pulse" />
              <span className="text-cyan-400 font-mono text-sm tracking-wider">
                NEURAL_NETWORK_STATUS: ONLINE
              </span>
            </div>
            
            <h3 className="text-2xl font-bold text-white mb-3 font-poppins">
              Continuous Learning Protocol
            </h3>
            
            <p className="text-gray-300 mb-6 max-w-md mx-auto">
              Skills evolving through advanced machine learning algorithms and real-world project implementation
            </p>
            
            <div className="flex flex-wrap justify-center gap-3">
              {['Deep Learning', 'Neural Networks', 'Computer Vision', 'NLP'].map((tech, index) => (
                <span 
                  key={index}
                  className="px-4 py-2 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 rounded-full text-sm font-medium text-cyan-300 border border-cyan-500/30 hover:border-cyan-400/50 transition-all duration-300 cursor-pointer hover:shadow-lg hover:shadow-cyan-500/20"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
