
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Github, Instagram, Youtube, Linkedin, Facebook, Phone, Mail, MapPin } from 'lucide-react';

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Add form submission logic here
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const socialStats = [
    {
      platform: 'YouTube',
      icon: Youtube,
      count: '110',
      label: 'Subscribers',
      color: 'text-red-500',
      bgColor: 'bg-red-50 dark:bg-red-950/20',
      borderColor: 'border-red-200 dark:border-red-800'
    },
    {
      platform: 'Instagram',
      icon: Instagram,
      count: '15.1K',
      label: 'Followers',
      color: 'text-pink-500',
      bgColor: 'bg-pink-50 dark:bg-pink-950/20',
      borderColor: 'border-pink-200 dark:border-pink-800'
    },
    {
      platform: 'GitHub',
      icon: Github,
      count: '5+',
      label: 'Repositories',
      color: 'text-gray-700 dark:text-gray-300',
      bgColor: 'bg-gray-50 dark:bg-gray-950/20',
      borderColor: 'border-gray-200 dark:border-gray-800'
    }
  ];

  const contactInfo = [
    {
      icon: Mail,
      label: 'Email',
      value: 'najishanjum058@gmail.com',
      href: 'mailto:najishanjum058@gmail.com'
    },
    {
      icon: Phone,
      label: 'WhatsApp',
      value: '+91 7631296157',
      href: 'https://wa.me/917631296157'
    },
    {
      icon: MapPin,
      label: 'Location',
      value: 'India',
      href: null
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-blue-50 via-white to-blue-100 dark:from-gray-900 dark:via-gray-800 dark:to-blue-900/20 font-inter">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-4 font-poppins">
            Get In <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Touch</span>
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Let's connect and discuss exciting opportunities in technology and innovation
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-gray-800/50 backdrop-blur-sm p-8 rounded-2xl shadow-lg border border-blue-100 dark:border-gray-700 transition-all duration-300 hover:shadow-xl">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 font-poppins">Send Me a Message</h3>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Full Name</label>
                    <Input
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Enter your full name"
                      className="border-gray-300 dark:border-gray-600 focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700/50 dark:text-white transition-all duration-300"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                    <Input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="Enter your email"
                      className="border-gray-300 dark:border-gray-600 focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700/50 dark:text-white transition-all duration-300"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Message</label>
                  <Textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Tell me about your project or just say hello!"
                    rows={6}
                    className="border-gray-300 dark:border-gray-600 focus:border-blue-500 focus:ring-blue-500 resize-none dark:bg-gray-700/50 dark:text-white transition-all duration-300"
                    required
                  />
                </div>

                <Button 
                  type="submit"
                  size="lg"
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white transition-all duration-300 transform hover:scale-105"
                >
                  Send Message ✨
                </Button>
              </form>
            </div>
          </div>

          {/* Contact Info & Social Stats */}
          <div className="space-y-6">
            {/* Contact Information */}
            <div className="bg-white dark:bg-gray-800/50 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-blue-100 dark:border-gray-700 transition-all duration-300 hover:shadow-xl">
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 font-poppins">Contact Details</h4>
              <div className="space-y-4">
                {contactInfo.map((info, index) => (
                  <div key={index} className="flex items-center space-x-3 text-gray-600 dark:text-gray-300 group">
                    <div className="p-2 rounded-lg bg-blue-50 dark:bg-blue-900/20 group-hover:bg-blue-100 dark:group-hover:bg-blue-900/40 transition-all duration-300">
                      <info.icon className="w-4 h-4 text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform duration-300" />
                    </div>
                    {info.href ? (
                      <a 
                        href={info.href}
                        className="text-sm hover:text-blue-600 dark:hover:text-blue-400 transition-colors duration-300"
                        target={info.href.startsWith('http') ? '_blank' : undefined}
                        rel={info.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                      >
                        {info.value}
                      </a>
                    ) : (
                      <span className="text-sm">{info.value}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Social Media Stats */}
            <div className="bg-white dark:bg-gray-800/50 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-blue-100 dark:border-gray-700 transition-all duration-300 hover:shadow-xl">
              <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 font-poppins">Social Presence</h4>
              <div className="space-y-4">
                {socialStats.map((social, index) => (
                  <div 
                    key={index}
                    className={`flex items-center justify-between p-3 rounded-lg border ${social.bgColor} ${social.borderColor} hover:shadow-md transition-all duration-300 cursor-pointer group`}
                  >
                    <div className="flex items-center space-x-3">
                      <social.icon className={`w-5 h-5 ${social.color} group-hover:scale-110 transition-transform duration-300`} />
                      <span className="font-medium text-gray-800 dark:text-gray-200">{social.platform}</span>
                    </div>
                    <div className="text-right">
                      <div className={`font-bold ${social.color}`}>{social.count}</div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">{social.label}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Contact */}
            <div className="bg-gradient-to-r from-blue-600 to-blue-500 dark:from-blue-700 dark:to-blue-600 p-6 rounded-2xl text-white">
              <h4 className="text-lg font-semibold mb-2 font-poppins">Quick Response</h4>
              <p className="text-sm text-blue-100 mb-4">
                I usually respond within 24 hours. Let's build something amazing together!
              </p>
              <div className="flex space-x-2">
                <Button 
                  variant="secondary" 
                  size="sm"
                  className="bg-white text-blue-600 hover:bg-blue-50 transition-all duration-300 transform hover:scale-105"
                  onClick={() => window.open('https://wa.me/917631296157', '_blank')}
                >
                  WhatsApp
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="border-white text-white hover:bg-white hover:text-blue-600 transition-all duration-300 transform hover:scale-105"
                >
                  Email
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
