
import { Button } from '@/components/ui/button';
import { Github, Star } from 'lucide-react';

const ProjectsSection = () => {
  const projects = [
    {
      title: 'KGN Collection',
      subtitle: 'E-Commerce Mobile App',
      description: 'A modern e-commerce application built with Flutter featuring user authentication, product catalog, shopping cart, and payment integration.',
      image: 'https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=600&h=400&fit=crop',
      tech: ['Flutter', 'Firebase', 'Stripe API'],
      github: '#',
      demo: '#',
      featured: true
    },
    {
      title: 'AI Photo Enhancer',
      subtitle: 'Computer Vision Project',
      description: 'Machine learning application that enhances photo quality using deep learning algorithms and image processing techniques.',
      image: 'https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b?w=600&h=400&fit=crop',
      tech: ['Python', 'TensorFlow', 'OpenCV'],
      github: '#',
      demo: '#',
      featured: false
    },
    {
      title: 'Portfolio Website',
      subtitle: 'Personal Brand',
      description: 'Responsive portfolio website showcasing projects, skills, and achievements with modern UI/UX design principles.',
      image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&h=400&fit=crop',
      tech: ['React', 'Tailwind CSS', 'TypeScript'],
      github: '#',
      demo: '#',
      featured: false
    },
    {
      title: 'Smart Home IoT',
      subtitle: 'IoT Solution',
      description: 'Internet of Things project for home automation with sensor integration and mobile app control interface.',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop',
      tech: ['Arduino', 'React Native', 'Firebase'],
      github: '#',
      demo: '#',
      featured: false
    }
  ];

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Featured <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Projects</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A collection of my recent work showcasing various technologies and creative solutions
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div 
              key={index}
              className="group bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2"
            >
              {/* Project Image */}
              <div className="relative overflow-hidden">
                <img 
                  src={project.image}
                  alt={project.title}
                  className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
                />
                {project.featured && (
                  <div className="absolute top-4 left-4">
                    <span className="flex items-center px-3 py-1 bg-blue-600 text-white text-xs font-medium rounded-full">
                      <Star className="w-3 h-3 mr-1" />
                      Featured
                    </span>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>

              {/* Project Content */}
              <div className="p-6">
                <div className="mb-4">
                  <h3 className="text-xl font-bold text-gray-900 mb-1">{project.title}</h3>
                  <p className="text-blue-600 font-medium text-sm">{project.subtitle}</p>
                </div>

                <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                  {project.description}
                </p>

                {/* Tech Stack */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tech.map((tech, techIndex) => (
                    <span 
                      key={techIndex}
                      className="px-3 py-1 bg-blue-50 text-blue-700 text-xs font-medium rounded-full border border-blue-100"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="flex-1 border-gray-300 hover:border-blue-300 hover:text-blue-600"
                  >
                    <Github className="w-4 h-4 mr-2" />
                    Code
                  </Button>
                  <Button 
                    size="sm"
                    className="flex-1 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600"
                  >
                    Live Demo
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View More Projects Button */}
        <div className="text-center mt-12">
          <Button 
            variant="outline"
            size="lg"
            className="border-blue-300 text-blue-600 hover:bg-blue-50"
          >
            View All Projects on GitHub
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;
