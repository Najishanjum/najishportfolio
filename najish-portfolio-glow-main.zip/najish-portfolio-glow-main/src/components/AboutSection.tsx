const AboutSection = () => {
  const profileInfo = [
    { label: 'Name', value: 'Md Najish Anjum' },
    { label: 'Age', value: '18 years old' },
    { label: 'Location', value: 'India' },
    { label: 'Education', value: 'B.Tech CSE (AI & ML)' }
  ];

  const interests = [
    { icon: '🤖', title: 'Artificial Intelligence', desc: 'Machine Learning & Deep Learning' },
    { icon: '💻', title: 'Web Development', desc: 'Full-stack applications' },
    { icon: '📱', title: 'Mobile Apps', desc: 'Flutter & React Native' },
    { icon: '🎨', title: 'UI/UX Designer', desc: 'Creating intuitive user experiences' },
    { icon: '🧠', title: 'Gen AI', desc: 'Generative AI & Large Language Models' },
    { icon: '🎮', title: 'Gaming', desc: 'Strategy & adventure games' }
  ];

  const achievements = [
    { icon: '🏆', title: 'Top Performer', desc: 'Academic Excellence' },
    { icon: '🎯', title: 'Project Leader', desc: 'Team Management' },
    { icon: '💡', title: 'Innovation', desc: 'Creative Problem Solving' },
    { icon: '🌟', title: 'Recognition', desc: 'Community Contribution' }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            About <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Me</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A passionate student exploring the intersection of technology and creativity
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {/* Profile Info Card */}
          <div className="lg:col-span-1">
            <div className="bg-gradient-to-br from-blue-50 to-white p-8 rounded-2xl shadow-lg border border-blue-100 h-full">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Profile</h3>
              <div className="space-y-4">
                {profileInfo.map((item, index) => (
                  <div key={index} className="flex justify-between items-center py-2 border-b border-blue-100 last:border-b-0">
                    <span className="text-gray-600 font-medium">{item.label}</span>
                    <span className="text-gray-900 font-semibold">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="lg:col-span-2">
            <div className="bg-gradient-to-br from-white to-blue-50 p-8 rounded-2xl shadow-lg border border-blue-100 h-full">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Who I Am</h3>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  I'm a dedicated <strong className="text-blue-600">B.Tech Computer Science (AI & ML)</strong> student 
                  with an insatiable curiosity for technology and innovation. My journey in tech started early, 
                  and I've been passionate about creating solutions that make a difference.
                </p>
                <p>
                  I believe in continuous learning and staying updated with the latest technological trends. 
                  My goal is to bridge the gap between artificial intelligence and practical applications 
                  that can benefit society.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Interests & Hobbies */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Interests & <span className="text-blue-600">Hobbies</span>
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {interests.map((interest, index) => (
              <div 
                key={index}
                className="bg-white p-6 rounded-xl shadow-md border border-gray-100 hover:shadow-lg hover:border-blue-200 transition-all duration-300 transform hover:-translate-y-1"
              >
                <div className="text-3xl mb-3">{interest.icon}</div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">{interest.title}</h4>
                <p className="text-gray-600 text-sm">{interest.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements */}
        <div>
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            <span className="text-blue-600">Achievements</span> & Recognition
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {achievements.map((achievement, index) => (
              <div 
                key={index}
                className="bg-gradient-to-br from-blue-50 to-white p-6 rounded-xl shadow-md border border-blue-100 text-center hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
              >
                <div className="text-4xl mb-3">{achievement.icon}</div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">{achievement.title}</h4>
                <p className="text-gray-600 text-sm">{achievement.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
