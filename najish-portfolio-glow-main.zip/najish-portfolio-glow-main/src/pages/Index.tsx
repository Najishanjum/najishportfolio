
import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import SkillsSection from '@/components/SkillsSection';
import SocialCounterSection from '@/components/SocialCounterSection';
import ProjectsSection from '@/components/ProjectsSection';
import ContactSection from '@/components/ContactSection';
import { Github, Instagram, Youtube, Linkedin, Mail, Phone } from 'lucide-react';

const Index = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen font-inter">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <SkillsSection />
      <SocialCounterSection />
      <ProjectsSection />
      <ContactSection />
      
      {/* Enhanced Footer */}
      <footer className="bg-gray-900 dark:bg-gray-950 text-white py-12 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                Najish Anjum
              </h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                AI/ML Student & Developer passionate about creating innovative solutions with cutting-edge technologies.
              </p>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-white">Quick Links</h4>
              <nav className="flex flex-col space-y-2">
                <button
                  onClick={() => scrollToSection('home')}
                  className="text-gray-400 hover:text-blue-400 transition-colors text-left text-sm"
                >
                  Home
                </button>
                <button
                  onClick={() => scrollToSection('about')}
                  className="text-gray-400 hover:text-blue-400 transition-colors text-left text-sm"
                >
                  About
                </button>
                <button
                  onClick={() => scrollToSection('skills')}
                  className="text-gray-400 hover:text-blue-400 transition-colors text-left text-sm"
                >
                  Skills
                </button>
                <button
                  onClick={() => scrollToSection('projects')}
                  className="text-gray-400 hover:text-blue-400 transition-colors text-left text-sm"
                >
                  Projects
                </button>
                <button
                  onClick={() => scrollToSection('contact')}
                  className="text-gray-400 hover:text-blue-400 transition-colors text-left text-sm"
                >
                  Contact
                </button>
              </nav>
            </div>

            {/* Social Media */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-white">Follow Me</h4>
              <div className="flex flex-col space-y-3">
                <a
                  href="#"
                  className="flex items-center space-x-3 text-gray-400 hover:text-red-500 transition-colors group"
                >
                  <Youtube className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  <span className="text-sm">YouTube</span>
                </a>
                <a
                  href="#"
                  className="flex items-center space-x-3 text-gray-400 hover:text-pink-500 transition-colors group"
                >
                  <Instagram className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  <span className="text-sm">Instagram</span>
                </a>
                <a
                  href="#"
                  className="flex items-center space-x-3 text-gray-400 hover:text-blue-400 transition-colors group"
                >
                  <Github className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  <span className="text-sm">GitHub</span>
                </a>
                <a
                  href="#"
                  className="flex items-center space-x-3 text-gray-400 hover:text-blue-600 transition-colors group"
                >
                  <Linkedin className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  <span className="text-sm">LinkedIn</span>
                </a>
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-white">Get In Touch</h4>
              <div className="flex flex-col space-y-3">
                <a
                  href="mailto:najishanjum058@gmail.com"
                  className="flex items-center space-x-3 text-gray-400 hover:text-blue-400 transition-colors group"
                >
                  <Mail className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  <span className="text-sm">najishanjum058@gmail.com</span>
                </a>
                <a
                  href="tel:+917631296157"
                  className="flex items-center space-x-3 text-gray-400 hover:text-green-400 transition-colors group"
                >
                  <Phone className="w-5 h-5 group-hover:scale-110 transition-transform" />
                  <span className="text-sm">+91 7631296157</span>
                </a>
              </div>
            </div>
          </div>

          {/* Bottom Section */}
          <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2025 Najish Anjum. All rights reserved.
            </p>
            <p className="text-gray-400 text-sm flex items-center">
              Built with <span className="text-blue-400 mx-1">💙</span> using React
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
