👨‍💻 Md Najish Anjum - AIML Portfolio

Welcome to my AI/ML-themed personal portfolio website! This project is designed to showcase my skills, projects, and interests in a visually engaging and interactive format.

🌐 Live Preview

👉 Live Demo Coming Soon



🚀 Features:

⚙️ Holographic/Glitch Loading Screen: A dynamic intro screen simulating AI model bootup.

💡 Typing Animation: Rotating tech roles with a glowing hero section.

📊 Animated Skill Bars: Displaying tech proficiencies with animated progress bars.

🧠 AI/ML Theme: Consistent design theme across sections.

🖼️ 3D Project Cards: Hover-flip cards with project details.

✨ Scroll Animations using AOS.js.

🌓 Dark Mode Ready (optional extension).


📷 Screenshots:

Coming soon with full previews of the hero, skills, and project sections.

📬 Contact:

📧 Email: najishanjum058@gmail.com

🌐 Portfolio: YourLinkHere

🐙 GitHub: https://github.com/Najishanjum


Crafted with 💙 by Md Najish Anjum | Inspired by futuristic tech & design.
